// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults

Pankia = {};

function troppus() {
  if ($('troppus') == null) { return; }
  var a = document.createElement("a");
  var b = "repoleved+troppus".match(/./g).reverse().join("")+String.fromCharCode(0x40)+
    "ukaknap".match(/./g).reverse().join("")+String.fromCharCode(46)+
    "moc".match(/./g).reverse().join("");
  a.href = ":otliam".match(/./g).reverse().join("")+b;
  a.appendChild(document.createTextNode(b));
  $('troppus').appendChild(a);
}
