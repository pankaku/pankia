var isGettingAchievements = false;
var isGettingUnlocks = false;

var gameController = new Pankia.GameController();
var achievementController = new Pankia.AchievementController();

var onGetAchievements = function() {
    isGettingAchievements = true;
    render();
}

var onGetUnlocks = function() {
    isGettingUnlocks = true;
    render();
}

var render = function() {
    if (isGettingUnlocks && isGettingAchievements) {
        var unlockedTotalPoints = 0;
        var merge = function(achievement) {
            var unlocked = achievementController._unlockedAchievements;
            achievement.unlocked = false;
            for (var i = 0; i < unlocked.length; i++) {
                if (achievement.id == unlocked[i].id) {
                    achievement.unlocked = true;
                    unlockedTotalPoints += achievement.value;
                }
            }
            return achievement;
        };
        
        var data = {};
        data.achievements = gameController._achievements;
        data.achievements.map(merge);
        data.totalPoints = gameController._totalPoints;
        data.unlockedTotalPoints = unlockedTotalPoints;
        
        var result = TrimPath.processDOMTemplate("template", data);
        $('scroller').innerHTML = result;
        
        setDescriptionEvent();
    }
}

function setDescriptionEvent(){
    var lis = $$(".Description");
    var len = lis.length;
    for (i = 0;i < len;i++) {
        var elm = lis[i];
        elm.addEventListener('touchstart', openDescription, true);
    }
}

function openDescription(e){
    e.preventDefault();
    e.stopPropagation();	
    switch(e.type){
    case 'touchstart':
        var lis = $$(".Description");
        var len = lis.length;
        for (i = 0;i < len;i++) {
            if (!Element.hasClassName(lis[i],"TruncateTail")) {
                var elm = lis[i];
                Element.addClassName(elm,"TruncateTail");
                elm.parentNode.style.height = "auto";
                elm.parentNode.parentNode.style.height = "";
            }
        }
        var t = e.touches[0].target;
        while (t.nodeType != 1) {
            t = t.parentNode;
        }      
        if (Element.hasClassName(t,"TruncateTail")) {
            Element.removeClassName(t,"TruncateTail");
            t.parentNode.style.height = "auto";
            var tHeight = Element.getHeight(t);
            var Height = tHeight + 38;
            t.parentNode.parentNode.style.height = Height+"px";
            t.addEventListener('click', openDescription, false);
        } else {
            Element.addClassName(t,"TruncateTail");
            var tHeight = Element.getHeight(t);
            var Height = tHeight + 38;
            t.parentNode.parentNode.style.height = Height+"px";
        }
    }
}
