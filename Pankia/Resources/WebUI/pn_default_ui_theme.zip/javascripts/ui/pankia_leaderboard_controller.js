Pankia.LeaderboardController = function(leaderboardId) {
    this._leaderboardId = leaderboardId;
};

Pankia.LeaderboardController.prototype = {
    requestScores: function(period, segment, offset, limit, callback) {
        if (segment == 'world' || segment == 'friends') {
            var that = this;
            //PankiaConnect.Action('leaderboard', 'scores', {'leaderboard':this._leaderboardId, 'period':period, 'among':segment}, function(json) {
            var params = {'leaderboard':this._leaderboardId, 'period':period, 'among':segment, 'offset': offset, 'limit': limit};
            PankiaConnect.Action('leaderboard', 'scores', params, function(json) {
                that._scores = json.scores;
                callback();
            });
        }
    },

    requestMyRank: function(callback) {
        this._requestRank({'leaderboards':[this._leaderboardId]}, callback);
    },

    requestUserRank: function(username, callback) {
        this._requestRank({'leaderboards':[this._leaderboardId], 'user': username}, callback);
    },

    _requestRank: function(params, callback) {
        var that = this;
        PankiaConnect.Action('leaderboard', 'rank', params, function(json) {
            that._myRank = json.ranks[0].value;
            that._isRanked = json.ranks[0].is_ranked;

            if (json.ranks[0].score.user) {
                that._myScore = json.ranks[0].score.value;
            }
            else {
                that._myScore = json.ranks[0].score;
            }

            callback();
        });
    },

    onScoresSuccess: function(json) {
        eval("var ajson = " + json);
        this._scores = ajson.scores;
        this.callback();
    },
    
    onMyRankSuccess: function(json) {
        eval("var ajson = " + json);
        this._myRank = ajson.ranks[0].value;
        this._isRanked = ajson.ranks[0].is_ranked;
        
        if (ajson.ranks[0].score.user) {
            this._myScore = ajson.ranks[0].score.value;
        } else {
            this._myScore = ajson.ranks[0].score;
        }
        this.callback();
    }
};
