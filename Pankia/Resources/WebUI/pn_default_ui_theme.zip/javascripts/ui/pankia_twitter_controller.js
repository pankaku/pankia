Pankia.TwitterController = function() {
}

Pankia.TwitterController.prototype = {
    requestLink: function(username, password, callback) {
        if (username && password) {
            PankiaConnect.Action('twitter', 'link', {"account": username, "password": password}, function(json) {
                callback();
            });
        }
    },

    requestUnlink: function(callback) {
        PankiaConnect.Action('twitter', 'unlink', {}, function(json) {
            callback();
        });
    },
    
    requestImportGraph: function(callback) {
        PankiaConnect.Action('twitter', 'import_graph', {}, function(json) {
            callback();
        });
    }
};
