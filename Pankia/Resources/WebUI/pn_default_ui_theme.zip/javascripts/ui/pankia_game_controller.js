Pankia.GameController = function() {
};

Pankia.GameController.prototype = {
    requestShow: function(gameId, callback) {
        var that = this;
        PankiaConnect.Action('game', 'show', {"game": gameId}, function(json) {
            that._game = json.game;
            callback();
        });
    },

    requestAchievements: function(callback) {
        var that = this;
        PankiaConnect.Action('game', 'achievements', {}, function(json) {
            that._totalPoints = 0;

            for (var i = 0; i < json.achievements.length; i++) {
                if (PankiaConnect.isVersionAdapted(json.achievements[i].min_version, json.achievements[i].max_version)) {
                    that._totalPoints += json.achievements[i].value;
                } else {
                    delete json.achievements[i];
                }
            }
            that._achievements = json.achievements;
            callback();
        });
    },

    requestLeaderboards: function(callback) {
        var that = this;
        PankiaConnect.Action('game', 'leaderboards', {}, function(json) {
            that._leaderboards = json.leaderboards;
            for (var i = 0; i < json.leaderboards.length; i++) {
                if (!PankiaConnect.isVersionAdapted(json.leaderboards[i].min_version, json.leaderboards[i].max_version)) {
                    delete json.leaderboards[i];
                }
            }
            callback();
        });
    },

    requestCategories: function(callback) {
        var that = this;
        PankiaConnect.Action('game', 'categories', {}, function(json) {
            that._categories = json.categories;
            for (var i = 0; i < json.categories.length; i++) {
                if (!PankiaConnect.isVersionAdapted(json.categories[i].min_version, json.categories[i].max_version)) {
                    delete json.categories[i];
                }
            }
            callback();
        });
    },

    requestMerchandises: function(callback) {
        var that = this;
        PankiaConnect.Action('game', 'merchandises', {}, function(json) {
            that._merchandises = json.merchandises;
            for (var i = 0; i < json.merchandises.length; i++) {
                if (!PankiaConnect.isVersionAdapted(json.merchandises[i].min_version, json.merchandises[i].max_version)) {
                    delete json.merchandises[i];
                }
            }
            callback();
        });
    },

    requestItems: function(callback) {
        var that = this;
        PankiaConnect.Action('game', 'items', {}, function(json) {
            that._items = json.items;
            for (var i = 0; i < json.items.length; i++) {
                if (!PankiaConnect.isVersionAdapted(json.items[i].min_version, json.items[i].max_version)) {
                    delete json.items[i];
                }
            }
            callback();
        });
    },

    findItem: function(itemId) {
      for (var i = 0; i < this._items.length; i++) {
        if (this._items[i].id == itemId) {
          return this._items[i];
        }
      }
      return null;
    },

    findItemByCategory: function(categoryId) {
      for (var i = 0; i < this._items.length; i++) {
        if (this._items[i].category_id == categoryId) {
          return this._items[i];
        }
      }
      return null;
    },

    findCategory: function(categoryId) {
      for (var i = 0; i < this._categories.length; i++) {
        if (this._categories[i].id == categoryId) {
          return this._categories[i];
        }
      }
      return null;
    },

    findMerchandise: function(merchandiseId) {
      for (var i = 0; i < this._merchandises.length; i++) {
        if (this._merchandises[i].id == merchandiseId) {
          return this._merchandises[i];
        }
      }
      return null;
    },

    findMerchandisesByCategory: function(categoryId) {
      var merchandises = [];
      for (var i = 0; i < this._merchandises.length; i++) {
        if (this._merchandises[i].item.category.id == categoryId) {
          merchandises.push(this._merchandises[i]);
        }
      }
      return merchandises;
    },

    findMerchandisesByItem: function(itemId) {
      var merchandises = [];
      for (var i = 0; i < this._merchandises.length; i++) {
        if (this._merchandises[i].item.id == itemId) {
          merchandises.push(this._merchandises[i]);
        }
      }
      return merchandises;
    }
};
