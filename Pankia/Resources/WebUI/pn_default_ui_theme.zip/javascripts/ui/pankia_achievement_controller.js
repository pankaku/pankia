Pankia.AchievementController = function() {
};

Pankia.AchievementController.prototype = {
    requestUnlocks: function(username, callback) {
        var that = this;
        var func = function(json) {
            //TODO
            //下のusername なし問題の エラー回避の為のコード
            that._unlockedAchievements = json.unlocks || [];
            callback();
        }

        if (username) {
            PankiaConnect.Action('achievement', 'unlocks', {'user': username}, func);
        } else {
            //TODO
            //username なしだと status:error を返しています
            PankiaConnect.Action('achievement', 'unlocks', {}, func);
        }
    }
};
