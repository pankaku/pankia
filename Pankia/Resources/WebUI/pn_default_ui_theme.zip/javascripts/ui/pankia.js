var Pankia = function() {
    var apiDomain;
    var callbackCount;
    var cookieKey;
    var sessionId;
    var counter;
    var retryCount;
    var session;
    //var ui;
    var debug;

  return {
  initialize: function(options) {
    apiDomain = window.location.host;
    apiDomain = 'pankia.com';
    callbackCount = 1;
    cookieKey = '__pankia';

    Object.extend(this, options || {});
    sessionId = sessionId || this.getCookie(this.cookieKey);
    counter = 0;
    retryCount = 0;

    // Classes included in this file
    //session = new Pankia.Session(this);

    // Define this class in user code. Callbacks get kicked here.
    //ui = new Pankia.UI(this);
    //this.user = new Pankia.User(this);
    //this.achievement = new Pankia.Achievement(this);

    // Turn this to true if you need verbose debug logs in Firebug console.
    // You can also change this on the fly, by typing "pankia.debug = true" in Firebug.

    debug = !this.isProduction();
  },

  boot: function() {
    this.dispatchEvent(null, 'Boot'); // This will call Pankia.UI.onBoot()
  },

  setCookie: function(key, value, days) {
    if (days) {
      var date = new Date();
      date.setTime(date.getTime()+(days*24*60*60*1000));
      var expires = "; expires="+date.toGMTString();
    }
    else var expires = "";
    document.cookie = key + "=" + value + expires+"; path=/";
  },

  getCookie: function(key) {
    var keyEQ = key + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
      var c = ca[i];
      while (c.charAt(0)==' ') c = c.substring(1,c.length);
      if (c.indexOf(keyEQ) == 0) return c.substring(keyEQ.length,c.length);
    }
    return null;
  },

  clearCookie: function(key) {
    this.setCookie(key, '', -1);
  },

  request: function(controller, action, params, options) {
    var path = '/' + controller.toLowerCase() + '/' + action.toLowerCase();
    console.debug("Url :" + path);
    params = params || {};
    options = options || {};
    var head = document.getElementsByTagName('head')[0];
    var script;

    var callbackName = 'callback' + callbackCount;
    var timerName = 'timer' + callbackCount;
    callbackCount++;

    Pankia[callbackName] = function(json) {
      if (json && json.status == 'ok') {
        (options.onSuccess || this.emptyFunction)(json);
      } else {
        (options.onFailure || this.emptyFunction)(json);
      }
      (options.onComplete || this.emptyFunction)(json);

      $(script).remove();
      if (json != null) {
        clearTimeout(Pankia[timerName]);
      }
      delete Pankia[callbackName];
      delete Pankia[timerName];

    }.bind(this);

    params.callback = 'Pankia.' + callbackName;

    try {
      script = new Element('script', {
        'type': 'text/javascript',
        'charset': 'UTF-8',
        'src': this.url(path, options.isObserve) + '?' + $H(params).toQueryString()
      });	
      head.appendChild(script);
      Pankia[timerName] = function() {
        //alert(callbackName);
        Pankia[callbackName](null);
      }.delay(60);
    } catch(e) {
      (options.onException || this.emptyFunction)(this, e);
    }
  },

  url: function(path) {
    var full;
    full = "http://" + apiDomain + '/api' + path;
    if (this.debug) { console.log(full) }
    return full;
  },

  dispatchEvent: function(controllerName, eventName, json) {
    var ui = Pankia.UI;
    if (controllerName && ui[controllerName]) {
      ui[controllerName]['on' + eventName].bind(ui)(json)
    } else if (ui['on' + eventName]) {
      ui['on' + eventName].bind(ui)(json)
    }
  },

  isProduction: function() {
    return !!apiDomain.match('pankia');
  },

  emptyFunction: function() {}
  }
}();


