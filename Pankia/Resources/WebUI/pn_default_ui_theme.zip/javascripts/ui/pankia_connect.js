
if (!PankiaConnect) {
	  var PankiaConnect = new Object;
}

//各種情報
PankiaConnect.Version = "1.0";
PankiaConnect.Prefix = "pankia://localhost/";
PankiaConnect.sessionID;
PankiaConnect.appVersion;

//ユーティリティメソッド
PankiaConnect.Utility = new Object;
PankiaConnect.Utility.Logs = new Array();
PankiaConnect.Utility.Console = function (text) {
	  PankiaConnect.Utility.Logs.unshift(text);
	  if (PankiaConnect.Utility.Logs.length > 5) {
		    PankiaConnect.Utility.Logs.shift();
	  }
	  var statusString = "";
    for (var i = 0; i < PankiaConnect.Utility.Logs.length; i++) {
		    statusString += " > " + PankiaConnect.Utility.Logs[i];
	  }
	  window.status = statusString;
}

PankiaConnect._guidCounter = 0;
PankiaConnect.getGuid = function() {
    return ++this._guidCounter;
}

PankiaConnect.onMessage = {
    listeners: [],
    addListener: function(guid, func) {
        this.listeners[guid] = func;
    }
};

PankiaConnect._postMessage = function(guid, message) {
    PankiaConnect.onMessage.listeners[guid](message);
}

//クッキー用ユーティリティ
//http://www.tohoho-web.com/wwwcook3.htm
PankiaConnect.Utility.Cookie = new Object();
PankiaConnect.Utility.Cookie.getCookie = function(key,  tmp1, tmp2, xx1, xx2, xx3) {
    tmp1 = " " + document.cookie + ";";
    xx1 = xx2 = 0;
    len = tmp1.length;
    while (xx1 < len) {
        xx2 = tmp1.indexOf(";", xx1);
        tmp2 = tmp1.substring(xx1 + 1, xx2);
        xx3 = tmp2.indexOf("=");
        if (tmp2.substring(0, xx3) == key) {
            return(unescape(tmp2.substring(xx3 + 1, xx2 - xx1 - 1)));
        }
        xx1 = xx2 + 1;
    }
    return("");
}

PankiaConnect.Utility.Cookie.setCookie = function(key, val, tmp) {
    tmp = key + "=" + escape(val) + "; ";
    // tmp += "path=" + location.pathname + "; ";
    tmp += "expires=Tue, 31-Dec-2030 23:59:59; ";
    document.cookie = tmp;
}

PankiaConnect.Utility.Cookie.clearCookie = function(key) {
    document.cookie = key + "=" + "xx; expires=Tue, 1-Jan-1980 00:00:00;";
}

//デリゲートメソッド
if (!PankiaConnect.Delegate) {
	  PankiaConnect.Delegate = new Object;
}
if (!PankiaConnect.Delegate.FinishInitalization) {
	  PankiaConnect.Delegate.FinishInitalization = function() {
		    PankiaConnect.Utility.Console("Finish Initalization with session ID:" + PankiaConnect.SessionID);
	  }
}

//通信用メソッド
PankiaConnect.Action = function (controllerName, actionName, params, callback) {
    var guid = this.getGuid();
    this.onMessage.addListener(guid, callback || function() {});
    
    var urlString = PankiaConnect.Prefix + controllerName + "/" + actionName;
    urlString += "?guid=" + guid;
    
    for (var index in params) {
        urlString += ("&" + index + "=" + params[index]);
    }
    
    if (navigator.userAgent.indexOf("iPhone OS", 0) != -1) {
        PankiaConnect.NativeAction(urlString);
    } else {
        PankiaConnect.Debug(urlString);
    }
};

PankiaConnect.NativeActionQueue = new Array();

PankiaConnect.NativeAction = function(actionURL) {
	  if (PankiaConnect.NativeActionIsRunning) {
		    PankiaConnect.NativeActionQueue.push(actionURL);
		    return;
	  }
	  PankiaConnect.NativeActionIsRunning = true;
	  location.href = actionURL;
	  setTimeout(PankiaConnect.NativeActionUnlock, 1);
}

PankiaConnect.NativeActionUnlock = function() {
    PankiaConnect.NativeActionIsRunning = false;
    if (PankiaConnect.NativeActionQueue.length) {
	      var nextURL = PankiaConnect.NativeActionQueue[0];
	      PankiaConnect.NativeActionQueue.shift();
	      PankiaConnect.NativeAction(nextURL);
    }
}

//デバッグ用メソッド
PankiaConnect.Debug = function(actionURL) {
    var tmp = actionURL.substr(PankiaConnect.Prefix.length, actionURL.length - PankiaConnect.Prefix.length).split("?");
    var argv = new Array();
    argv.push(tmp[0]);
    
    var params = new Hash();
    if (tmp.length == 2) {
        tmp = tmp[1].split("&");
        for (var i=0; i<tmp.length; i++) {
            var knv = tmp[i].split("=");
            params[knv[0]] = knv[1];
        }
    }
    
    if (params["callback"]) {
        argv.push(params["callback"]);
    } else {
        argv.push("alert");
    }
    
    var ret = "OK";
    if (argv[0] == "dashboard/close") {
        alert("Dashboard is closed.");
        eval(argv[1] + "()");
        return;
    } else if (argv[0] == "session/session") {
        ret = PankiaConnect.Utility.Cookie.getCookie("Session");
        
        if (!ret || ret == 'null') {
            ret = name=prompt("Please Type Session ID", "3u4XPh");
            PankiaConnect.Utility.Cookie.setCookie("Session", ret);
        }
        eval(argv[1] + "('" + ret + "');");
    } else if (argv[0] == "application/basicInformation") {
        var sessionID = PankiaConnect.Utility.Cookie.getCookie("Session");
        
        if (!sessionID || sessionID == 'null') {
            sessionID = name=prompt("Please Type Session ID", "3u4XPh");
            PankiaConnect.Utility.Cookie.setCookie("Session", ret);
        }
        
        ret = "{\"session\":\"" + sessionID + "\", \"version\":\"1.0\"}";
        
        eval(argv[1] + "('" + ret + "');");
    }
}

PankiaConnect.ResetDebugSettings = function() {
    PankiaConnect.Utility.Cookie.clearCookie("Session");
}

//初期化コード
PankiaConnect.Initalization = function() {
    PankiaConnect.Action("application", "basicInformation", {}, PankiaConnect.FinishInitalization);
}

PankiaConnect.FinishInitalization = function(json) {
    PankiaConnect.sessionID = json.session;
    PankiaConnect.appVersion = json.version;
    PankiaConnect.Action("dashboard", "hideIndicator", {});
    Pankia.initialize({sessionId:PankiaConnect.SessionID,});
    PankiaConnect.Delegate.FinishInitalization();
}

//初期化処理の実行 (prototype)
document.observe('dom:loaded', function(){
    PankiaConnect.Initalization();
});

// バージョン比較
PankiaConnect.isVersionAdapted = function(minVersion, maxVersion) {
    var appVersion = PankiaConnect.appVersion;
    //var appVersion = "5.19.1";
    //alert("app:" + appVersion + " min:" + minVersion + " max:" + maxVersion);
    
    var appVersionArray = appVersion.split('.');
    var isMinAdapted = true;
    var isMaxAdapted = true;
    
    if (minVersion) {
        var minVersionArray = minVersion.split('.');
        for (var i = 0; i < appVersionArray.length; i++) {
            if (parseInt(appVersionArray[i]) < parseInt(minVersionArray[i])) {
                var isMinAdapted = false;
            }
        }
    }
    if (maxVersion) {
        var maxVersionArray = maxVersion.split('.');
        for (var i = 0; i < appVersionArray.length; i++) {
            if (parseInt(appVersionArray[i]) > parseInt(maxVersionArray[i])) {
                var isMaxAdapted = false;
            }
        }
    }
    return (isMinAdapted && isMaxAdapted);
}