Pankia.UserController = function() {
}

Pankia.UserController.prototype = {
    requestShow: function(username, callback) {
        var that = this;
        var func = function(json) {
            that._user = json.user;
            callback();
        };
        
        if (username) {
            PankiaConnect.Action('user', 'show', {"user": username, "include": "enrollments"}, func);
        } else {
            PankiaConnect.Action('user', 'show', {"include": "enrollments"}, func );
        }
    },

    requestSecure: function(email, password, callback) {
        if (email && password) {
            PankiaConnect.Action('user', 'secure', {"email": email, "password": password}, function(json) {
                callback();
            });
        }
    },

    requestFollowees: function(username, callback) {
        var that = this;
        var func = function(json) {
            //TODO followeesとfollowersが共に_firendsに代入してて事故る可能性大
            that._friends = json.followees;
            callback();
        };
        
        if (username) {
            PankiaConnect.Action('user', 'followees', {"user": username}, func);
        } else {
            PankiaConnect.Action('user', 'followees', {}, func);
        }
    },

    requestFollowers: function(username, callback) {
        var that = this;
        var func = function(json) {
            //TODO followeesとfollowersが共に_firendsに代入してて事故る可能性大
            that._friends = json.followers;
            callback();
        };
        
        if (username) {
            PankiaConnect.Action('user', 'followers', {"user": username}, func);
        } else {
            PankiaConnect.Action('user', 'followers', {}, func);
        }
    },

    requestFollow: function(username, callback) {
        if (username) {
            PankiaConnect.Action('user', 'follow', {"user": username}, function(json) {
                if (json.status === "ok") {
                    callback();
                }
            });
        }
    },
    
    requestUnfollow: function(username, callback) {
        if (username) {
            PankiaConnect.Action('user', 'unfollow', {"user": username}, function(json) {
                if (json.status === "ok") {
                    callback();
                }
            });
        }
    },
    
    requestBlock: function(username, callback) {
        if (username) {
            PankiaConnect.Action('user', 'block', {"user": username}, function(json) {
                if (json.status === "ok") {
                    callback();
                }
            });
        }
    },
    
    requestUnblock: function(username, callback) {
        if (username) {
            PankiaConnect.Action('user', 'unblock', {"user": username}, function(json) {
                if (json.status === "ok") {
                    callback();
                }
            });
        }
    },
    
    requestUpdate: function(username) {
        if (username) {
            PankiaConnect.Action('user', 'update', {"username": username});
        }
    },
    
    requestTwitterIconUrl: function(twitterId, callback) {
        var that = this;
        PankiaConnect.Action('user', 'twitterIconUrl', {"user_id": twitterId}, function(twitterIconUrl) {
            that._twitterIconUrl = twitterIconUrl;
            callback();
        });
    },

    findGame: function(gameId) {
        var that = this;
        if (that._user.enrollments) {
            var enrollments = that._user.enrollments;
            for (var i = 0; i < enrollments.length; i++) {
                if (gameId == enrollments[i].game.id) {
                    return enrollments[i];
                }
            }
        }
        return null;
    }
};
