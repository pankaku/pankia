Pankia.ItemController = function() {
};

Pankia.ItemController.prototype = {
    requestOwnerships: function(callback) {
        var that = this;
        PankiaConnect.Action('item', 'ownerships', {}, function(json) {
            // TODO json._ownerships がなぜか[] からalert評価するとhttp://localhost になる
            that._ownerships = json.ownerships;
            callback();
        });
    },
    
    findOwnership: function(itemId) {
        for (var i = 0; i < this._ownerships.length; i++) {
            if (itemId == this._ownerships[i].item_id) {
                return this._ownerships[i];
            }
        }
        return null;
    }
};
