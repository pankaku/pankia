Pankia = {}
Pankia.TimeZone = Class.create({
  initialize: function() {
    var rightNow = new Date();
  	var jan1 = new Date(rightNow.getFullYear(), 0, 1, 0, 0, 0, 0);  // jan 1st
  	var june1 = new Date(rightNow.getFullYear(), 6, 1, 0, 0, 0, 0); // june 1st
  	var temp = jan1.toGMTString();
  	var jan2 = new Date(temp.substring(0, temp.lastIndexOf(" ")-1));
  	temp = june1.toGMTString();
  	var june2 = new Date(temp.substring(0, temp.lastIndexOf(" ")-1));
  	this.utc_offset = (jan1 - jan2) / 1000;
  	var daylight_time_offset = (june1 - june2) / 1000;
  	if (this.utc_offset == daylight_time_offset) {
  		this.dst = 0; // daylight savings time is NOT observed
  	} else {
  		// positive is southern, negative is northern hemisphere
  		var hemisphere = this.utc_offset - daylight_time_offset;
  		if (hemisphere >= 0)
  			this.utc_offset = daylight_time_offset;
  		this.dst = 1; // daylight savings time is observed
  	}
	},
	
	utc_offset_in_hours: function() {
	  return this.utc_offset / (60 * 60);
	}
});
